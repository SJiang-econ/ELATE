import numpy as np
import pandas as pd


def gen(n=1000, beta_d=1.0, beta_z=1.0, seed=123):
    """
    Generate data according to the DGP used in the ELATE Monte Carlo.

    Parameters
    ----------
    n : int
        Sample size.
    beta_d : float
        Treatment effect.
    beta_z : float
        Direct effect of instrument.
    seed : int
        Random seed.

    Returns
    -------
    Y : np.ndarray, shape (n,)
    D : np.ndarray, shape (n,), binary
    Z : np.ndarray, shape (n,), binary
    X : pd.DataFrame, shape (n, 2)
    """
    rng = np.random.default_rng(seed)

    # -----------------------
    # Exogenous variables
    # -----------------------
    z0 = rng.normal(0, 1, n)
    x1 = rng.normal(0, 1, n)
    x2 = rng.normal(0, 1, n)

    # errors
    v = rng.normal(0, 1, n)
    u = v + rng.normal(0, 1, n)

    # -----------------------
    # Instrument
    # -----------------------
    Z = (z0 > 0).astype(int)
    


    # -----------------------
    # Treatment
    # -----------------------
    d1 = (1 + x1 - x2 + v > 0).astype(int)
    d0 = (x1 - x2 + v > 0).astype(int)
    D = d1 * Z + d0 * (1 - Z)

    # -----------------------
    # Outcome
    # -----------------------
    s = x1 + x2 - 2 * x1 * x2 + u

    y00 = s
    y01 = s + beta_z
    y10 = s + beta_d
    y11 = s + beta_z + beta_d

    Y = y00 * (1 - D) * (1 - Z)+ y01 * (1 - D) * Z+ y10 * D * (1 - Z)+ y11 * D * Z
    

    # -----------------------
    # Covariates
    # -----------------------
    X = pd.DataFrame({
        "x1": x1,
        "x2": x2
    })

    return Y, D, Z, X
