import numpy as np
import pandas as pd
import itertools
from sklearn.linear_model import LogisticRegression
import statsmodels.api as sm
from scipy import stats


class ELATEResult:
    def __init__(self, coef, stderr, tstat, pvalue):
        self.coef_ = coef
        self.stderr_ = stderr
        self.tstat_ = tstat
        self.pvalue_ = pvalue
        
    def summary(self):
        """
        Return a formatted summary table of ELATE results.
        """
        table = pd.DataFrame({
            "coef": self.coef_,
            "std err": self.stderr_,
            "t": self.tstat_,
            "P>|t|": self.pvalue_
        })

        return table


class ELATE:
    """
    ELATE v1.0
    Estimation of (beta_d1, beta_z) with series first stage and bootstrap inference.
    """

    def __init__(self, Y, D, Z, X, degree=2):
        #self.Y = np.asarray(Y).reshape(-1)
        #self.D = np.asarray(D).reshape(-1)
        #self.Z = np.asarray(Z).reshape(-1)
        #self.X = X.copy()


        #self.Y = np.asarray(Y).reshape(-1)
        #self.D = np.asarray(D).reshape(-1)
        #self.Z = np.asarray(Z).reshape(-1)
        #重置索引，确保索引是 0, 1, 2... 且与 Y 对齐
        #self.X = X.copy().reset_index(drop=True) 

        # 强制转换为 1D Numpy 数组
        self.degree=degree
        self.Y = np.asarray(Y).ravel()
        self.D = np.asarray(D).ravel()
        self.Z = np.asarray(Z).ravel()
        # 确保 X 是干净的 DataFrame
        self.X = pd.DataFrame(X).copy().reset_index(drop=True)
        self._check_inputs()

        

        self._check_inputs()

    # -----------------------
    # Input checks
    # -----------------------
    def _check_inputs(self):
        n = len(self.Y)

        if not (len(self.D) == len(self.Z) == n):
            raise ValueError("Y, D, Z must have the same length.")

        if not isinstance(self.X, pd.DataFrame):
            raise TypeError("X must be a pandas DataFrame.")

        if self.X.shape[0] != n:
            raise ValueError("X must have the same number of rows as Y.")

        if np.any(pd.isnull(self.X)):
            raise ValueError("X contains missing values.")

        if not set(np.unique(self.D)).issubset({0, 1}):
            raise ValueError("D must be binary {0,1}.")

        if not set(np.unique(self.Z)).issubset({0, 1}):
            raise ValueError("Z must be binary {0,1}.")

    # -----------------------
    # Polynomial sieve
    # -----------------------
    

    


    @staticmethod
    def _poly_series(X: pd.DataFrame, degree: int = 2) -> pd.DataFrame:
        """
        Build a polynomial series (sieve) of arbitrary degree.

        Parameters
        ----------
        X : pd.DataFrame
            Covariates, shape (n, k)
        degree : int
            Maximum polynomial degree (>=1)

        Returns
        -------
        pd.DataFrame
            Polynomial series without constant term
        """
        if degree < 1:
            raise ValueError("degree must be >= 1")

        X = X.copy()
        cols = list(X.columns)
        n = X.shape[0]

        out = pd.DataFrame(index=X.index)

        k = len(cols)

        # generate all monomials up to given degree
        # exponent vectors like (e1, e2, ..., ek) with sum(ei) <= degree
        for total_deg in range(1, degree + 1):
            for powers in itertools.combinations_with_replacement(range(k), total_deg):
                # powers is something like (0,0,1) -> x1^2 * x2
                term = np.ones(n)
                name_parts = []

                for j in range(k):
                    exp = powers.count(j)
                    if exp > 0:
                        term *= X.iloc[:, j] ** exp
                        name_parts.append(f"{cols[j]}^{exp}" if exp > 1 else cols[j])

                col_name = "*".join(name_parts)
                out[col_name] = term

        return out

    

    
    # -----------------------
    # One estimation run
    # -----------------------
    def _estimate_once(self, Y, D, Z, X):
        n = len(Y)

        # build sieve
        SX =self._poly_series(X, self.degree)

        # ---- E(Z | X) via logit
        logit_z = LogisticRegression(solver="lbfgs", max_iter=1000,penalty=None)
        logit_z.fit(SX, Z)
        Ez_x = logit_z.predict_proba(SX)[:, 1]
        z_res = Z - Ez_x

        # ---- E(D | Z=z, X)
        SX0 = SX[Z == 0]
        SX1 = SX[Z == 1]

        logit_d0 = LogisticRegression(solver="lbfgs", max_iter=1000,penalty=None)
        logit_d1 = LogisticRegression(solver="lbfgs", max_iter=1000,penalty=None)

        logit_d0.fit(SX0, D[Z == 0])
        logit_d1.fit(SX1, D[Z == 1])

        Ed0_x = logit_d0.predict_proba(SX)[:, 1]
        Ed1_x = logit_d1.predict_proba(SX)[:, 1]

        lambda1_x = Ed1_x - Ed0_x

        # ---- E(Y | X)
        SX_const = sm.add_constant(SX)
        reg_y = sm.OLS(Y, SX_const).fit()
        Ey_x = reg_y.predict(SX_const).values

        # ---- Second stage
        W = Y - Ey_x
        A = np.column_stack([lambda1_x * z_res, z_res])

        beta = sm.OLS(W, A).fit().params
        #beta = np.linalg.pinv(A) @ W

        #print(">>> USING PINV SECOND STAGE <<<")


        return beta

    # -----------------------
    # Public API
    # -----------------------
    def fit(self, bootstrap=200, seed=123):
        np.random.seed(seed)

        # point estimate
        beta_hat = self._estimate_once(self.Y, self.D, self.Z, self.X)

        # bootstrap
        n = len(self.Y)
        boot = np.zeros((bootstrap, 2))

        for b in range(bootstrap):
            idx = np.random.choice(n, n, replace=True)
            boot[b, :] = self._estimate_once(
                self.Y[idx],
                self.D[idx],
                self.Z[idx],
                self.X.iloc[idx].reset_index(drop=True)
            )

        se = boot.std(axis=0, ddof=1)
        tstat = beta_hat / se
        pvalue = 2 * (1 - stats.norm.cdf(np.abs(tstat)))

        return ELATEResult(
            coef=pd.Series(beta_hat, index=["beta_d1", "beta_z"]),
            stderr=pd.Series(se, index=["beta_d1", "beta_z"]),
            tstat=pd.Series(tstat, index=["beta_d1", "beta_z"]),
            pvalue=pd.Series(pvalue, index=["beta_d1", "beta_z"])
        )
